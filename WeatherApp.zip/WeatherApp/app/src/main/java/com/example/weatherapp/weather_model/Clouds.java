package com.example.weatherapp.weather_model;

public class Clouds {
    private String _value;
    private String _all;
    private String _unit;


    // Getter Methods

    public String get_value() {
        return _value;
    }

    public String get_all() {
        return _all;
    }

    public String get_unit() {
        return _unit;
    }
}
