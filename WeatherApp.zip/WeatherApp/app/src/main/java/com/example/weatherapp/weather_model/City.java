package com.example.weatherapp.weather_model;

public class City {
    private String name;


    public String getName() {
        return name;
    }
}