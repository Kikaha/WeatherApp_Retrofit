package com.example.weatherapp.weather_model;

public class Meta {
    private String lastupdate;
    private String calctime;
    private String nextupdate;


    // Getter Methods

    public String getLastupdate() {
        return lastupdate;
    }

    public String getCalctime() {
        return calctime;
    }

    public String getNextupdate() {
        return nextupdate;
    }
}
