package com.example.weatherapp.weather_model;

public class Temperature {
    private String _day;
    private String _min;
    private String _max;
    private String _night;
    private String _eve;
    private String _morn;


    // Getter Methods

    public String get_day() {
        return _day;
    }

    public String get_min() {
        return _min;
    }

    public String get_max() {
        return _max;
    }

    public String get_night() {
        return _night;
    }

    public String get_eve() {
        return _eve;
    }

    public String get_morn() {
        return _morn;
    }
}
